var myDate=function () {
    return Date();
    };
    exports.myDate = myDate;